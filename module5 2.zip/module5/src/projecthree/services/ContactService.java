package projecthree.services;

import java.util.HashMap;
import java.util.Map;

import projecthree.model.Contact;

public class ContactService {
	
	//           key      value
	private Map<String, Contact> contacts;

	public ContactService() {
		contacts = new HashMap<>();
	}
	
	
	public boolean addContact(Contact contact) {
		if(contacts.containsKey(contact.getID())) {
			return false;
		}
        contacts.put((String) contact.getID(), contact);
        return true;
	}
	
	public boolean deleteContact(Contact contact) {
		return contacts.remove(contact.getID()) != null ;
	}
	
	public boolean updateContact(Contact contact) {
		Contact temp = contacts.get(contact.getID());
		if(temp != null) {
			temp.setFirstName(contact.getFirstName());
			temp.setLastName(contact.getLastName());
			temp.setPhone(contact.getPhone());
			temp.setAddress(contact.getAddress());
			return true;
		}
		return false;
		
	}

	

}
