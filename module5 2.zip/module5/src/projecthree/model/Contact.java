package projecthree.model;

public class Contact {
	private String ID = "";
	private String firstName;	
	private String lastName;
	private String phone;
	private String address;
	
	


	public Contact(String iD, String firstName, String lastName, String phone, String address) {
		if(isValid(ID)) {
			ID = iD;			
  	     }
		setFirstName(firstName);
		setLastName(lastName);
		setPhone(phone);
		setAddress(address);
	}
	

	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		if(isValid(firstName)) {
			this.firstName = firstName;			
  	     }
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		if(isValid(lastName)) {
			this.lastName = lastName;			
  	     }
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		if(isValid(phone)) {
			this.phone = phone;			
  	     }
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		if(address !=null && address.length() > 0 && address.length() <30) {
			this.address = address;			
  	     }
	}



//	public void setID(String iD) {
//		if(ID!=null && ID.length() <=10) {
//			ID = iD;			
//		}
//	}
	
	private boolean isValid(String input) {return input!=null && input.length() > 0 && input.length() <=10; }


	public Object getID() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
