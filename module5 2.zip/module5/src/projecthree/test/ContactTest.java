package projecthree.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Test;

import projecthree.model.Contact;

class ContactTest {
	
	Contact contact;
	
	@BeforeEach
	void setup() {
		contact = new Contact("1234",
				"mike",
				"fara",
				"5188888888",
				"mf@gmail.com"
				);
	}

	@Test
	void testgetFirstNameValidInputTrue() {
		assertEquals("mike", contact.getFirstName());
	}

	@Test
	void testSetFirstNameValidInValidInputTrue() {
		contact.setFirstName("michael");
		assertEquals("michael", contact.getFirstName());
	}

	@Test
	void testSetFirstNameValidInputTrue() {
		contact.setFirstName("John");
		assertEquals("John", contact.getFirstName());
	}

	@Test
	void testSetFirstNameInValidInputLengthTrue() {
		contact.setFirstName("Jhonnnnnnnn");
		assertEquals("mike", contact.getFirstName());
		
	}
	@Test
	void testSetAddressInvalidInputLengthTrue() {
		contact.setAddress("FRANKYY22222222222222222222222222222222222222222222222222222222222222222222222222222222222222@GMAIL.COM");
		assertEquals("mf@gmail.com",contact.getAddress());
	}

}