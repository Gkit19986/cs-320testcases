package module5.services;

import java.util.HashMap;
import java.util.Map;

import module5.model.Appointment;


public class AppointmentService {
	
	private Map<String, Appointment> appointments;

	public AppointmentService() {
		appointments = new HashMap<>();
	}
	
	
	public boolean addAppointment(Appointment appointment) {
		if(appointments.containsKey(appointment.getID())) {
			return false;
		}
		appointments.put(appointment.getID(), appointment);
        return true;
	}
	
	public boolean deleteAppointment(Appointment appointment) {
		return appointments.remove(appointment.getID()) != null ;
	}
		
}
