package module5.model;

import java.util.Date;

public class Appointment {

	private Date date;
	private String ID;
	private String description;

	public Appointment(Date date, String ID, String description) {
		setDate(date);
		setDescription(description);
		if(isValid(ID, 10)) {
			this.ID = ID;
		}
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		if (isNotInPast(date)) {
			this.date = date;
		} else {
			System.out.println("Appointment date cannot be in the past");
		}
	}

	public String getID() {
		return ID;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		if (isValid(description, 50)) {
			this.description = description;
		}
	}

	private boolean isValid(String input, int bound) {
		return input != null && input.length() > 0 && input.length() <= bound;
	}

	private boolean isNotInPast(Date date) {
		return date != null && !date.before(new Date());
	}
}