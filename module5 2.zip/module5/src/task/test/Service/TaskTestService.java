package task.test.Service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import task.Service.TaskService;
import task.model.Task;

class TaskTestService {
private TaskService service;
	
	@BeforeEach
	void setUp() throws Exception {
		service = new TaskService();
		
	}

	@Test
	void testAddEmptyTaskFalse() {
		assertTrue(service.addTask(new Task("4567","Mike", "desc")));
	}

	@ Test
    void testDeleteTaskTrue() {
		   assertFalse(service.deleteTask("4567"));
	   assertTrue(service.addTask(new Task("4567","Mike", "desc")));
	   assertTrue(service.deleteTask("4567"));
	}

	@Test
	void TestDeleteTaskFalse() {
		assertTrue(service.addTask(new Task("556767","unkown","description feild missing)")));
		assertTrue(service.deleteTask("556776"));
	}
@Test
void testUpdatetask() {
	assertFalse(service.updateTask(new Task("45667","Mikee","desc")));
	service.addTask(new Task("45667","michael", "empty"));
	assertTrue(service.updateTask(new Task("45667","Mikee","desc")));
}

	
	}


