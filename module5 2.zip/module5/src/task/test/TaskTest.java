package task.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import task.model.Task;

class TaskTest {

	Task task;

	@BeforeEach
	void setUp() throws Exception {
		task = new Task("1234","mikee","add");
	}

	@Test
	void testSetNameValidInputLengthTrue() {
		task.setName("mikee");
		assertEquals("mikee",task.getName());
	}
	@Test
	void testSetNameInvalidInputLengthFalse() {
		task.setName("no nameeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
		assertEquals("no nameeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",task.getName());
		//assertNotEquals("no nameeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",task.getName());
		//which will return true
	}
@Test
void testSetDescpritionValidLengthTrue() {
	task.setDesc("information overload");
	assertEquals("information overload",task.getDesc());
}
@Test
void SetDescriptionInvalidLengthFalse() {
	task.setDesc("information overloaddddddddddddddddddddddddddd!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
	assertEquals("information overloaddddddddddddddddddddddddddd!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",task.getDesc());
	//assertNotEquals("information overloaddddddddddddddddddddddddddd!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",task.getDesc());
	//which will return true 
}
}

