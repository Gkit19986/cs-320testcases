package task.model;

public class Task {
	private String ID;
	private String name;
	private String desc;
	
	public Task(String ID, String name, String desc) {
		if(isValid(ID, 10)) {this.ID = ID ;}
		setName(name);
		setDesc(desc);
	}
	
	private boolean isValid(String input, int upBound) {
		return input != null && input.length() <= upBound;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		if(isValid(name, 20)) {
			this.name = name;
		}		
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		if(isValid(desc, 50)) {
			this.desc = desc;	
		}
		}
		public String getID() {
			return ID;
		
}
}