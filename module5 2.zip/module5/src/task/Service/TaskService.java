package task.Service;
import java.util.HashMap;
import java.util.Map;

import task.model.*;

public class TaskService {
private Map<String, Task> records;
	
	public TaskService() {
		records = new HashMap<>();
	}
	
	public boolean addTask(Task task) {
		if(task.getID() == null || task.getID().isBlank() || records.containsKey(task.getID())) {
			return false;
		}
		records.put(task.getID(), task);
		return true;
	}
	
	public boolean updateTask(Task task) {
		Task temp = records.get(task.getID());
		if(temp != null ) {			
			temp.setDesc(task.getDesc());
			temp.setName(task.getName());
			return true;
		}
		return false;
	}
	
	public boolean deleteTask(String id) {
		return records.remove(id) != null;
	}
}
	

