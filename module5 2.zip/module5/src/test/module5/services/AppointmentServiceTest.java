package test.module5.services;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import module5.model.Appointment;
import module5.services.AppointmentService;

class AppointmentServiceTest {
	
	private AppointmentService service;
	@BeforeEach
	void setUp() throws Exception {
		new Date(System.currentTimeMillis() + 1000 * 60 * 60 );
		service = new AppointmentService();
	}

	@Test
	void testvalidAppointment() throws ParseException {
		Date date = new Date(System.currentTimeMillis() + 1000 * 60 * 60 );
		Appointment appointment = new Appointment(date, "11", "getting regular checkup");
		assertTrue(service.addAppointment(appointment));
	}
	
	@Test
	void TestInValidAddAppointment() {
		Date date = new Date(System.currentTimeMillis() + 1000 * 60 * 60 );
		Appointment appointment = new Appointment(date, "1", "New appointment");
		try {
			appointment.setDate(new SimpleDateFormat("yyyy-MM-dd").parse("2019-10-11"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		appointment.setDescription("sss");
		assertFalse(service.addAppointment(appointment));
		
	}
@ Test
void Deleteappointment() throws ParseException {
	Date date = new Date(System.currentTimeMillis() + 1000 * 60 * 60 );
	Appointment appointment = new Appointment(date, "14", "getting regular checkup");
	appointment.setDate(new SimpleDateFormat("yyyy-MM-dd").parse("2022-10-11"));
	assertFalse(service.deleteAppointment(appointment));
}
}





