package test.module5.model;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import module5.model.Appointment;

class AppointmentTest {
	
	Appointment appointment;

	@BeforeEach
	void setUp() throws Exception {
	
	}

	@Test
	void test() throws ParseException {
	Date date = new Date(System.currentTimeMillis() + 1000 * 60 * 60 );
		appointment = new Appointment(date, "11", "checkup");
		assertTrue(date.equals(appointment.getDate()));
		
	}
	
	@Test
	void testingfuturedate() throws ParseException{
		
		Date date = new SimpleDateFormat("yyyy-MM-dd").parse("2024-10-07");
		appointment = new Appointment(date, "11", "checkup");
		assertTrue(date.equals(appointment.getDate()));
	}
@Test
void testingPastDate() {
	Date date = new Date(System.currentTimeMillis() + 1000 * 60 * 60 );

	try {
		date = new SimpleDateFormat("yyyy-MM-dd").parse("1998-10-07");
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	appointment = new Appointment(date, "10", "checkup");
	
	assertFalse(date.equals(appointment.getDate()));
	
}
}